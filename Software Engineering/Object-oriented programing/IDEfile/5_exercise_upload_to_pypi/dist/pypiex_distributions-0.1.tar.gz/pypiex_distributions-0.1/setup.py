from setuptools import setup

setup(name='pypiex_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['pypiex_distributions'],
      zip_safe=False)
